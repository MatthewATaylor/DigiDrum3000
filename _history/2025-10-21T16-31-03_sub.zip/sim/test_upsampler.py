import random
import vicoco
import cocotb
from cocotb.triggers import Timer
import os
from pathlib import Path
import sys
import math

from cocotb.clock import Clock
from cocotb.triggers import (
    Timer,
    ClockCycles,
    RisingEdge,
    FallingEdge,
    ReadOnly,
    ReadWrite,
    with_timeout,
    First,
    Join,
)
from cocotb.utils import get_sim_time as gst
from vicoco.vivado_runner import get_runner

from random import getrandbits


def clamp(x, low, high):
    if x < low:
        return low
    if x > high:
        return high
    return x


async def reset(rst, clk):
    """Helper function to issue a reset signal to our module"""
    rst.value = 1
    await ClockCycles(clk, 3)
    rst.value = 0
    await ClockCycles(clk, 2)


def reverse_bits(n, size):
    reversed_n = 0
    for i in range(size):
        reversed_n = (reversed_n << 1) | (n & 1)
        n >>= 1
    return reversed_n


async def drive_sample(dut, sample, output_arr):
    await FallingEdge(dut.clk)
    if output_arr is not None:
        output_arr.append(dut.sample_out.value)
    dut.sample_in.value = int(sample * 2**15)
    dut.sample_in_valid.value = 1
    await FallingEdge(dut.clk)
    if output_arr is not None:
        output_arr.append(dut.sample_out.value)
    dut.sample_in_valid.value = 0
    for i in range(2270):
        await FallingEdge(dut.clk)
        if output_arr is not None:
            output_arr.append(dut.sample_out.value)


@cocotb.test()
async def test_upsampler(dut):
    """Your simulation test!
    TODO: Flesh this out with value sets and print statements. Maybe even some assertions, as a treat.
    """
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    # set all inputs to 0
    dut.sample_in.value = 0
    dut.sample_in_valid.value = 0
    # use helper function to assert reset signal
    await reset(dut.rst, dut.clk)
    out = []
    angle = 0
    delta_angle = 0.1
    for i in range(64):
        await drive_sample(dut, math.sin(angle), None)
        angle += delta_angle
    for i in range(64):
        await drive_sample(dut, math.sin(angle), out)
        angle += delta_angle
    for upsample in out:
        print(upsample)


def test_upsampler_runner():
    """Run the upsampler runner. Boilerplate code"""
    hdl_toplevel_lang = os.getenv("HDL_TOPLEVEL_LANG", "verilog")
    sim = os.getenv("SIM", "vivado")
    proj_path = Path(__file__).resolve().parent.parent
    sys.path.append(str(proj_path / "sim" / "model"))
    sources = [
        proj_path / "hdl" / "upsampler.sv",
        proj_path / "hdl" / "xilinx_single_port_ram_read_first.v",
        proj_path / "data" / "DAC_filter_coeffs.mem",
    ]
    build_test_args = ["-Wall"]
    parameters = {"K_SELECT": 5, "KERNEL_DIMENSION": 3}
    sys.path.append(str(proj_path / "sim"))
    runner = get_runner(sim)
    runner.build(
        sources=sources,
        hdl_toplevel="upsampler",
        always=True,
        build_args=build_test_args,
        parameters=parameters,
        timescale=("1ns", "1ps"),
        waves=True,
    )
    run_test_args = []
    runner.test(
        hdl_toplevel="upsampler",
        test_module="test_upsampler",
        test_args=run_test_args,
        waves=True,
    )


if __name__ == "__main__":
    test_upsampler_runner()
