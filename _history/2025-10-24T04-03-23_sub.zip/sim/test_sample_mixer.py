import cocotb
import os
import sys
from math import log
import logging
from pathlib import Path
from cocotb.clock import Clock
from cocotb.triggers import Timer, ClockCycles, RisingEdge, FallingEdge, ReadOnly,with_timeout
from cocotb.utils import get_sim_time as gst
from cocotb.runner import get_runner
test_file = os.path.basename(__file__).replace(".py","")


SAMPLE_PERIOD = 20


async def run_writer(dut, sample_sets):
    for samples in sample_sets:
        for i in range(SAMPLE_PERIOD):
            if i % 6 == 0:  # 0, 6, 12, 18
                sample = samples[int(i/6)]
                dut.din.value = int(sample)
                dut.din_valid.value = 1
            else:
                dut.din_valid.value = 0
            await ClockCycles(dut.clk, 1)


@cocotb.test()
async def test_a(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    dut.rst.value = 1
    await ClockCycles(dut.clk, 2)
    dut.rst.value = 0

    sample_sets = [
        [5e3, 6e3, 7e3, 8e3],      # Adding positive numbers (no clip)
        [1e4, 1e4, 1e4, 1e4],      # Adding positive numbers (with clip)
        [-1e3, -2e3, -3e3, -4e3],  # Adding negative numbers (no clip)
        [-1e4, -1e4, -1e4, -1e4],  # Adding negative numbers (with clip)
        [0,0,0,0],                 # Adding zeros
    ]

    cocotb.start_soon(run_writer(dut, sample_sets))

    await ClockCycles(dut.clk, 1)
    for samples in sample_sets:
        for i in range(SAMPLE_PERIOD):
            await ClockCycles(dut.clk, 1)

        print(f'Reading result from sample set: {samples}')

        assert dut.dout_valid.value == 1
        sample_sum = int(sum(samples))
        if sample_sum > 2**15 - 1:
            sample_sum = 2**15 - 1
        elif sample_sum < -2**15:
            sample_sum = -2**15
        print(f'Expected result: {sample_sum}')
        assert dut.dout.value.signed_integer == sample_sum


def is_runner():
    hdl_toplevel_lang = os.getenv("HDL_TOPLEVEL_LANG", "verilog")
    sim = os.getenv("SIM", "icarus")
    proj_path = Path(__file__).resolve().parent.parent
    sys.path.append(str(proj_path / "sim" / "model"))
    sources = [proj_path / "hdl" / "sample_mixer.sv"]
    build_test_args = ["-Wall"]
    parameters = {'SAMPLE_PERIOD': SAMPLE_PERIOD}
    hdl_toplevel = "sample_mixer"
    sys.path.append(str(proj_path / "sim"))
    runner = get_runner(sim)
    runner.build(
        sources=sources,
        hdl_toplevel=hdl_toplevel,
        always=True,
        build_args=build_test_args,
        parameters=parameters,
        timescale = ('1ns','1ps'),
        waves=True
    )
    run_test_args = []
    runner.test(
        hdl_toplevel=hdl_toplevel,
        test_module=test_file,
        test_args=run_test_args,
        waves=True
    )

if __name__ == "__main__":
    is_runner()

